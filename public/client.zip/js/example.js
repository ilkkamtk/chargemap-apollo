'use strict';

const apiURL = 'http://localhost:3000/graphql';

// html elements
const infoSection = document.getElementById('info-section');
const title = document.getElementById('title');
const address = document.getElementById('address');
const info = document.getElementById('info');
const button = document.getElementById('btn');

// array for charge icons so that extra icons can be removed
const layers = [];

// some properties are null, try to fix them
const checkNull = (obj) => {
  for (let [key, value] of Object.entries(obj)) {
    if (value === null) {
      obj[key] = '<i class="fas fa-question-circle"></i>';
    }
  }
  return obj;
};

// charge station icon
const fontAwesomeIcon = L.divIcon({
  html: '<i class="fas fa-charging-station fa-2x">',
  className: 'myDivIcon',
});

// add map
const map = L.map('map').setView([60.24, 24.74], 11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

// update map on move + zoom
map.on('moveend', function() {
  init();
});

// fetch stations from graphql API
const fetchStations = async (bounds) => {
  const query = {
    query: `{
  stations(bounds: ${bounds}) {
  Title
    Town
    AddressLine1
    Location {
      type
      coordinates
    }
    Connections {
      Quantity
      ConnectionType {
        Title
      }
      CurrentType {
        Title
      }
      LevelType {
        Title
        Comments
        IsFastChargeCapable
      }
    }
  }
}`,
  };

  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify(query),
  };
  try {
    const response = await fetch(apiURL, options);
    const json = await response.json();
    return json.data.stations;
  } catch (e) {
    console.log(e);
  }
};

// show icons on map and set popupopen event to show station info
const onEachFeature = (feature, layer) => {
  layers.push(layer);
  // does this feature have a property named popupContent?
  if (feature.properties && feature.properties.popupContent) {
    layer.bindPopup(feature.properties.popupContent).on('popupopen', () => {
      infoSection.classList.remove('hide');
      // reset fields
      title.innerHTML = '';
      address.innerHTML = '<i class="fas fa-at"></i>&nbsp;';
      info.innerHTML = '';

      // show info
      const {Title, Town, Address, Connections, Location} = feature.properties;
      title.innerHTML = Title;
      address.appendChild(document.createTextNode(`${Town}, ${Address}`));
      Connections.forEach((connection) => {

        checkNull(connection);
        const {Quantity, ConnectionType, CurrentType, LevelType} = connection;
        let fast = `, fast charge`;
        if (!LevelType.IsFastChargeCapable) {
          fast = '';
        }
        let acdcIcon = '&#9107';
        try {

          if (CurrentType.Title.includes('AC'))
            acdcIcon = '&#9190;';
        } catch (e) {
          console.log(e);
        }
        info.innerHTML += `
<div class="connection">
<p><i class="fas fa-plug"></i> ${ConnectionType.Title}</p>
<p><span class="icon">${acdcIcon}</span> ${CurrentType.Title}</p>
<p><i class="fas fa-bolt"></i> ${LevelType.Title}, ${LevelType.Comments}${fast}</p>
<p>Connections: ${Quantity}</p>
</div>
`;
      });
      // navigate button
      btn.href = `https://www.google.com/maps/dir/?api=1&destination=${Location.coordinates[1]},${Location.coordinates[0]}&travelmode=driving&dir_action=navigate`;

    });
    layer.setIcon(fontAwesomeIcon);
  }
};

// start other functions
const init = async (position) => {
  infoSection.scrollTop = 0;
  if (position) {
    const marker = L.marker(
        [position.coords.latitude, position.coords.longitude]).
        addTo(map).
        bindPopup('You are here.').
        openPopup();
    map.panTo(marker.getLatLng());
  }
  const bounds = JSON.stringify(map.getBounds()).
      replace(new RegExp('"', 'g'), '');
  const stations = await fetchStations(bounds);
  const features = stations.map((station) => {
    const {Title, Town, Location, AddressLine1, Connections} = station;
    const feature = {
      'type': 'Feature',
      'properties': {
        'Title': Title,
        'Town': Town,
        'Address': AddressLine1,
        'Connections': Connections,
        'popupContent': Title,
        'show_on_map': true,
        'Location': Location,
      },
      'geometry': Location,
    };
    return feature;
  });
  layers.forEach(layer => {
    map.removeLayer(layer);
  });

  layers.length = 0;

  L.geoJSON(features, {
    onEachFeature: onEachFeature,
  }).addTo(map);
};

// if user position not found
const reject = (e) => {
  console.log(e);
};

// options for getCurrentPosition
const options = {
  enableHighAccuracy: true,
  timeout: 5000,
  maximumAge: 0,
};

// get user location
navigator.geolocation.getCurrentPosition(init, reject, options);
